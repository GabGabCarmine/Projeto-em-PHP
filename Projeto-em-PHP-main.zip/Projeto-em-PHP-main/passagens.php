<!DOCTYPE html>
<html lang="en">
<head>
    <center>
    <meta charset="UTF-8">
    <title>Comprar passagens</title>
    <link rel="stylesheet" href="bootstrap.css">
    <style type="text/css">
        body{ font: 18px sans-serif; text-align: center; background-color: #87CEEB;}
    </style>
</head>
<body>
    <div class="page-header">
     <h2>Buscar Passagem</h2>
      </div>
    <p>
        
    <div class="styles__ContainerWrapper-sc-1kpaoz7-0 bOZzzt"><div class="styles__Header-sc-1kpaoz7-1 bbvMmU"><span class="styles__StyledText-sc-jikqhn-0 ikNLQl styles__FormHeader-sc-1kpaoz7-4 dQMrSv"/span></div><div class="styles__SearchChildrenContainer-sc-1kpaoz7-2 hsqQRv"><input type="hidden" value="MAO"><div class="MuiFormControl-root styles__FormControl-sc-qxqwj3-1 cCmFWU with-icon-on-the-left undefined undefined undefined undefined undefined with-placeholder styles__OverBackdropInput-sc-y7f0fe-2 dNmBQW styles__LocationSearch-sc-18ei0db-2 eIEpvI">
        <label class="MuiFormLabel-root MuiInputLabel-root styles__Label-sc-qxqwj3-3 cPhWok MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink MuiFormLabel-filled" data-shrink="true"<br> De onde você está saindo?

     </label><div class="styles__InputWrapper-sc-qxqwj3-2 hLdpQ"><div class="MuiInputBase-root styles__Input-sc-qxqwj3-0 jBezsK MuiInputBase-formControl"><input type="text" aria-invalid="false" placeholder="Busque um aeroporto"  class="MuiInputBase-input"></div><div class="styles__IconWrapper-sc-qxqwj3-5 gIZIAa"><i color="inherit" name="outlined-plane-departure" class="Icon__StyledIcon-sc-1aimh8k-0 bsMorC undefined theme-icon--outlined-plane-departure"></i></div></div></div><div class="MuiFormControl-root styles__FormControl-sc-qxqwj3-1 cCmFWU with-icon-on-the-left undefined undefined undefined false undefined with-placeholder styles__OverBackdropInput-sc-y7f0fe-2 dNmBQW styles__LocationSearch-sc-18ei0db-2 eIEpvI"><label class="MuiFormLabel-root MuiInputLabel-root styles__Label-sc-qxqwj3-3 cPhWok MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink MuiFormLabel-filled" data-shrink="true"<br> Para onde você vai? </label><div class="styles__InputWrapper-sc-qxqwj3-2 hLdpQ"><div class="MuiInputBase-root styles__Input-sc-qxqwj3-0 jBezsK MuiInputBase-formControl"><input type="text" aria-invalid="false" placeholder="Busque cidade" class="MuiInputBase-input"></div><div class="styles__IconWrapper-sc-qxqwj3-5 gIZIAa"><i color="inherit" name="outlined-location" class="Icon__StyledIcon-sc-1aimh8k-0 bsMorC undefined theme-icon--outlined-location"></i></div></div></div><div class="styles__BaseWrapper-sc-183adiw-2 ksJyYH styles__SizedDateRangePicker-sc-18ei0db-0 gXbzbw"><div class="styles__InputGroupContainer-sc-183adiw-7 eWNgrD"><span class="styles__StyledText-sc-jikqhn-0 tvonY styles__LabelsContainer-sc-183adiw-8 fWupxt"><label> Escolha o período</label><label for="datepicker-hotel-checkin"/label><label for="datepicker-hotel-checkout"/label></span><div class="DateRangePicker DateRangePicker_1"><div><div class="DateRangePickerInput DateRangePickerInput_1"i name="outlined-calendar-range" color="smoke" class="Icon__StyledIcon-sc-1aimh8k-0 SevWF styles__InputIcon-sc-183adiw-5 jUZNQX theme-icon--outlined-calendar-range"></i></button><div class="DateInput DateInput_1"><input type="text" class="DateInput_input DateInput_input_1" aria-label="Ida" id="datepicker-hotel-checkin" name="datepicker-hotel-checkin" placeholder="Ida" autocomplete="off" aria-describedby="DateInput__screen-reader-message-datepicker-hotel-checkin"><p class="DateInput_screenReaderMessage DateInput_screenReaderMessage_1" id="DateInput__screen-reader-message-datepicker-hotel-checkin"/p></div><div class="DateRangePickerInput_arrow DateRangePickerInput_arrow_1" aria-hidden="true" role="presentation"><i name="outlined-calendar-range" color="smoke" class="Icon__StyledIcon-sc-1aimh8k-0 SevWF styles__InputIcon-sc-183adiw-5 styles__SecondInputIcon-sc-183adiw-6 jUZNQX kqqtBr theme-icon--outlined-calendar-range"></i></div><div class="DateInput DateInput_1"><input type="text" class="DateInput_input DateInput_input_1" aria-label="Volta" id="datepicker-hotel-checkout" name="datepicker-hotel-checkout" placeholder="Volta" autocomplete="off" aria-describedby="DateInput__screen-reader-message-datepicker-hotel-checkout"><p class="DateInput_screenReaderMessage DateInput_screenReaderMessage_1" id="DateInput__screen-reader-message-datepicker-hotel-checkout"<p></div></div></div></div></div></div><div class="styles__SelectRoomsWrapper-sc-128aeuk-0 czmoxo"><div 

</table>
  <div style="padding-top:20px;">
    <center>
      <a href="passagensdisponiveis.php" role="button" class="btn btn-sm btn-primary">Buscar</a> <a href="../welcome.php" role="button" class="btn btn-sm btn-primary">Voltar</a>
    </center>
  </div>
